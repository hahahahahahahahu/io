﻿namespace io
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.la_LED = new System.Windows.Forms.Label();
            this.bt_LED_on = new System.Windows.Forms.Button();
            this.bt_LED_off = new System.Windows.Forms.Button();
            this.la_CAMERA = new System.Windows.Forms.Label();
            this.bt_CAMERA_on = new System.Windows.Forms.Button();
            this.bt_CAMERA_off = new System.Windows.Forms.Button();
            this.la_player1 = new System.Windows.Forms.Label();
            this.tb_msg = new System.Windows.Forms.TextBox();
            this.la_player2 = new System.Windows.Forms.Label();
            this.la_player3 = new System.Windows.Forms.Label();
            this.la_player4 = new System.Windows.Forms.Label();
            this.la_time = new System.Windows.Forms.Label();
            this.tb_time = new System.Windows.Forms.TextBox();
            this.bt_time_up = new System.Windows.Forms.Button();
            this.bt_time_down = new System.Windows.Forms.Button();
            this.tb_data = new System.Windows.Forms.TextBox();
            this.tb_player2 = new System.Windows.Forms.TextBox();
            this.tb_connect = new System.Windows.Forms.TextBox();
            this.tb_player1 = new System.Windows.Forms.TextBox();
            this.tb_player3 = new System.Windows.Forms.TextBox();
            this.tb_player4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // la_LED
            // 
            this.la_LED.AutoSize = true;
            this.la_LED.Location = new System.Drawing.Point(193, 199);
            this.la_LED.Name = "la_LED";
            this.la_LED.Size = new System.Drawing.Size(28, 12);
            this.la_LED.TabIndex = 0;
            this.la_LED.Text = "LED";
            // 
            // bt_LED_on
            // 
            this.bt_LED_on.Location = new System.Drawing.Point(195, 223);
            this.bt_LED_on.Name = "bt_LED_on";
            this.bt_LED_on.Size = new System.Drawing.Size(64, 36);
            this.bt_LED_on.TabIndex = 1;
            this.bt_LED_on.Text = "on";
            this.bt_LED_on.UseVisualStyleBackColor = true;
            this.bt_LED_on.Click += new System.EventHandler(this.bt_LED_on_Click);
            // 
            // bt_LED_off
            // 
            this.bt_LED_off.Location = new System.Drawing.Point(277, 223);
            this.bt_LED_off.Name = "bt_LED_off";
            this.bt_LED_off.Size = new System.Drawing.Size(64, 36);
            this.bt_LED_off.TabIndex = 1;
            this.bt_LED_off.Text = "off";
            this.bt_LED_off.UseVisualStyleBackColor = true;
            this.bt_LED_off.Click += new System.EventHandler(this.bt_LED_off_Click);
            // 
            // la_CAMERA
            // 
            this.la_CAMERA.AutoSize = true;
            this.la_CAMERA.Location = new System.Drawing.Point(357, 199);
            this.la_CAMERA.Name = "la_CAMERA";
            this.la_CAMERA.Size = new System.Drawing.Size(57, 12);
            this.la_CAMERA.TabIndex = 0;
            this.la_CAMERA.Text = "CAMERA";
            // 
            // bt_CAMERA_on
            // 
            this.bt_CAMERA_on.Location = new System.Drawing.Point(359, 223);
            this.bt_CAMERA_on.Name = "bt_CAMERA_on";
            this.bt_CAMERA_on.Size = new System.Drawing.Size(64, 36);
            this.bt_CAMERA_on.TabIndex = 1;
            this.bt_CAMERA_on.Text = "on";
            this.bt_CAMERA_on.UseVisualStyleBackColor = true;
            this.bt_CAMERA_on.Click += new System.EventHandler(this.bt_CAMERA_on_Click);
            // 
            // bt_CAMERA_off
            // 
            this.bt_CAMERA_off.Location = new System.Drawing.Point(441, 223);
            this.bt_CAMERA_off.Name = "bt_CAMERA_off";
            this.bt_CAMERA_off.Size = new System.Drawing.Size(64, 36);
            this.bt_CAMERA_off.TabIndex = 1;
            this.bt_CAMERA_off.Text = "off";
            this.bt_CAMERA_off.UseVisualStyleBackColor = true;
            this.bt_CAMERA_off.Click += new System.EventHandler(this.bt_CAMERA_off_Click);
            // 
            // la_player1
            // 
            this.la_player1.AutoSize = true;
            this.la_player1.Location = new System.Drawing.Point(25, 199);
            this.la_player1.Name = "la_player1";
            this.la_player1.Size = new System.Drawing.Size(46, 12);
            this.la_player1.TabIndex = 0;
            this.la_player1.Text = "player1";
            // 
            // tb_msg
            // 
            this.tb_msg.Location = new System.Drawing.Point(27, 58);
            this.tb_msg.Multiline = true;
            this.tb_msg.Name = "tb_msg";
            this.tb_msg.Size = new System.Drawing.Size(482, 124);
            this.tb_msg.TabIndex = 3;
            this.tb_msg.TextChanged += new System.EventHandler(this.tb_msg_TextChanged);
            // 
            // la_player2
            // 
            this.la_player2.AutoSize = true;
            this.la_player2.Location = new System.Drawing.Point(25, 272);
            this.la_player2.Name = "la_player2";
            this.la_player2.Size = new System.Drawing.Size(46, 12);
            this.la_player2.TabIndex = 0;
            this.la_player2.Text = "player2";
            // 
            // la_player3
            // 
            this.la_player3.AutoSize = true;
            this.la_player3.Location = new System.Drawing.Point(25, 343);
            this.la_player3.Name = "la_player3";
            this.la_player3.Size = new System.Drawing.Size(46, 12);
            this.la_player3.TabIndex = 0;
            this.la_player3.Text = "player3";
            // 
            // la_player4
            // 
            this.la_player4.AutoSize = true;
            this.la_player4.Location = new System.Drawing.Point(25, 416);
            this.la_player4.Name = "la_player4";
            this.la_player4.Size = new System.Drawing.Size(46, 12);
            this.la_player4.TabIndex = 0;
            this.la_player4.Text = "player4";
            // 
            // la_time
            // 
            this.la_time.AutoSize = true;
            this.la_time.Location = new System.Drawing.Point(71, 22);
            this.la_time.Name = "la_time";
            this.la_time.Size = new System.Drawing.Size(29, 12);
            this.la_time.TabIndex = 5;
            this.la_time.Text = "time";
            // 
            // tb_time
            // 
            this.tb_time.Location = new System.Drawing.Point(250, 12);
            this.tb_time.Multiline = true;
            this.tb_time.Name = "tb_time";
            this.tb_time.Size = new System.Drawing.Size(91, 31);
            this.tb_time.TabIndex = 6;
            // 
            // bt_time_up
            // 
            this.bt_time_up.Location = new System.Drawing.Point(359, 10);
            this.bt_time_up.Name = "bt_time_up";
            this.bt_time_up.Size = new System.Drawing.Size(64, 36);
            this.bt_time_up.TabIndex = 1;
            this.bt_time_up.Text = "up";
            this.bt_time_up.UseVisualStyleBackColor = true;
            this.bt_time_up.Click += new System.EventHandler(this.bt_time_up_Click);
            // 
            // bt_time_down
            // 
            this.bt_time_down.Location = new System.Drawing.Point(441, 10);
            this.bt_time_down.Name = "bt_time_down";
            this.bt_time_down.Size = new System.Drawing.Size(64, 36);
            this.bt_time_down.TabIndex = 1;
            this.bt_time_down.Text = "down";
            this.bt_time_down.UseVisualStyleBackColor = true;
            this.bt_time_down.Click += new System.EventHandler(this.bt_time_down_Click);
            // 
            // tb_data
            // 
            this.tb_data.Location = new System.Drawing.Point(117, 12);
            this.tb_data.Multiline = true;
            this.tb_data.Name = "tb_data";
            this.tb_data.Size = new System.Drawing.Size(118, 31);
            this.tb_data.TabIndex = 7;
            // 
            // tb_player2
            // 
            this.tb_player2.Location = new System.Drawing.Point(27, 299);
            this.tb_player2.Multiline = true;
            this.tb_player2.Name = "tb_player2";
            this.tb_player2.Size = new System.Drawing.Size(146, 34);
            this.tb_player2.TabIndex = 8;
            // 
            // tb_connect
            // 
            this.tb_connect.Location = new System.Drawing.Point(195, 272);
            this.tb_connect.Multiline = true;
            this.tb_connect.Name = "tb_connect";
            this.tb_connect.Size = new System.Drawing.Size(310, 205);
            this.tb_connect.TabIndex = 9;
            // 
            // tb_player1
            // 
            this.tb_player1.Location = new System.Drawing.Point(27, 223);
            this.tb_player1.Multiline = true;
            this.tb_player1.Name = "tb_player1";
            this.tb_player1.Size = new System.Drawing.Size(146, 34);
            this.tb_player1.TabIndex = 8;
            // 
            // tb_player3
            // 
            this.tb_player3.Location = new System.Drawing.Point(27, 368);
            this.tb_player3.Multiline = true;
            this.tb_player3.Name = "tb_player3";
            this.tb_player3.Size = new System.Drawing.Size(146, 36);
            this.tb_player3.TabIndex = 8;
            // 
            // tb_player4
            // 
            this.tb_player4.Location = new System.Drawing.Point(27, 441);
            this.tb_player4.Multiline = true;
            this.tb_player4.Name = "tb_player4";
            this.tb_player4.Size = new System.Drawing.Size(146, 36);
            this.tb_player4.TabIndex = 8;
            this.tb_player4.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(532, 496);
            this.Controls.Add(this.tb_connect);
            this.Controls.Add(this.tb_player1);
            this.Controls.Add(this.tb_player4);
            this.Controls.Add(this.tb_player3);
            this.Controls.Add(this.tb_player2);
            this.Controls.Add(this.tb_data);
            this.Controls.Add(this.tb_time);
            this.Controls.Add(this.la_time);
            this.Controls.Add(this.tb_msg);
            this.Controls.Add(this.la_player4);
            this.Controls.Add(this.la_player3);
            this.Controls.Add(this.bt_time_down);
            this.Controls.Add(this.bt_CAMERA_off);
            this.Controls.Add(this.la_player2);
            this.Controls.Add(this.bt_time_up);
            this.Controls.Add(this.bt_CAMERA_on);
            this.Controls.Add(this.la_player1);
            this.Controls.Add(this.bt_LED_off);
            this.Controls.Add(this.la_CAMERA);
            this.Controls.Add(this.bt_LED_on);
            this.Controls.Add(this.la_LED);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label la_LED;
        private System.Windows.Forms.Button bt_LED_on;
        private System.Windows.Forms.Button bt_LED_off;
        private System.Windows.Forms.Label la_CAMERA;
        private System.Windows.Forms.Button bt_CAMERA_on;
        private System.Windows.Forms.Button bt_CAMERA_off;
        private System.Windows.Forms.Label la_player1;
        private System.Windows.Forms.TextBox tb_msg;
        private System.Windows.Forms.Label la_player2;
        private System.Windows.Forms.Label la_player3;
        private System.Windows.Forms.Label la_player4;
        private System.Windows.Forms.Label la_time;
        private System.Windows.Forms.TextBox tb_time;
        private System.Windows.Forms.Button bt_time_up;
        private System.Windows.Forms.Button bt_time_down;
        private System.Windows.Forms.TextBox tb_data;
        private System.Windows.Forms.TextBox tb_player2;
        private System.Windows.Forms.TextBox tb_connect;
        private System.Windows.Forms.TextBox tb_player1;
        private System.Windows.Forms.TextBox tb_player3;
        private System.Windows.Forms.TextBox tb_player4;
    }
}

