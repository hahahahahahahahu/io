﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace io
{
    public partial class Form1 : Form
    {

        public bool[] player_late = new bool[5];
        public bool[] player_absent = new bool[5];
        public int hour=8, min=0;
        public int led = 0, camera = 0;
        public int[] player = new int[5];
        public int[,] player_data = new int[5, 5];
        public int Log_Num, Minute_Compare, Hour_Compare;
        public string line, text;
        public int time;
        public string[] msg_data = new string[6];
        public int day = 0;





        ArrayList socklist = new ArrayList();
        public static string data = null;
        //클라이언트에게 오는 메시지를 받을 버퍼 선언
        private byte[] bytes = new byte[1024];

        public List<string> clientIP = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
            SocketServer();
            iniInitialize();
           
            
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {


            save_data();
            if (socklist != null)
            {
                socklist = null;
            }
            Application.Exit();

        }

        public static string TruncateLeft(string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value)) return value;
            return value.Length <= maxLength ? value : value.Substring(0, maxLength);
        }

        public void SocketServer()
        {
            ClientIPStore();

            //클라이언트 IP를 알아서 해당 클라이언트에게 접속 요청
            new Thread(delegate ()
            {
                while (true)
                {
                    try
                    {
                        foreach (var client in clientIP)
                        {
                            // Create a TCP/IP Socket
                            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                            // 클라이언트의 IP와 포트번호를 이용해 접속 시도
                            //sock.Connect(new IPEndPoint(IPAddress.Parse(client.ToString()), 12000));
                            IPEndPoint endpoint = new IPEndPoint(IPAddress.Parse(client.ToString()), 12000);

                            //각 클라이언트 Search 할 때 Timeout 걸어준다.
                            IAsyncResult result = sock.BeginConnect(IPAddress.Parse(client.ToString()), 12000, null, null);
                            bool success = result.AsyncWaitHandle.WaitOne(500, true);

                            if (!success)
                            {
                                FailConnect(sock, client);
                            }
                            else
                            {
                                Invoke((MethodInvoker)delegate
                                {
                                    SuccessConnect(sock, client);
                                });
                            }
                        }
                    }
                    catch (SocketException se)
                    {
                        MessageBox.Show("해당 클라이언트가 없습니다.");
                    }
                    Invoke((MethodInvoker)delegate
                    {
                        tb_connect.AppendText(Environment.NewLine);
                        // tb_connect.AppendText(Environment.NewLine);
                    });
                    Thread.Sleep(5000);
                }
            }).Start();
        }

        private void SuccessConnect(Socket sock, string client)
        {
            //lbConnect.Items.Add(client.ToString() + "[IP의 Client 연결 성공].");
            tb_connect.AppendText(client.ToString() + "[IP의 Client 연결 성공]." + Environment.NewLine);
            socklist.Clear();
            //현재 연결 되어있는 클라이언트들만 따로 ArrayList에 저장
            socklist.Add(sock);
            new Thread(delegate ()
            {
                while (true)
                {
                    try
                    {
                        data = null;
                        // Client에서 들어오는 연결을 처리한다.
                        while (true)
                        {
                            bytes = new byte[1024];
                            int bytesRec = sock.Receive(bytes);
                            data += Encoding.UTF8.GetString(bytes, 0, bytesRec);
                            Thread.Sleep(500);
                            if (data.IndexOf("<eof>") > -1)
                            {
                                break;
                            }
                        }
                        // Truncate the <eof>
                        data = TruncateLeft(data, data.Length - 5);

                        // Client에서 받은 메시지를 listbox로 보여줍니다.
               //        Invoke((MethodInvoker)delegate
               //        {
               //            //lbRevMsg.Items.Add(string.Format("Text received : {0}", data));
               //            tb_ecv_msg.AppendText(string.Format(client.ToString() + "received : {0}", data) +
               //                                   Environment.NewLine);
               //        });
                        iomsg();
                        byte[] msg = Encoding.UTF8.GetBytes(data);
                        foreach (Socket socket in socklist)
                        {
                            socket.Send(msg);

                        }

                    }
                    catch
                    {
                        //MessageBox.Show("Server : DISCONNECTION!");
                        sock.Close();
                        sock.Dispose();
                        break;
                    }
                }
            }).Start();
        }

        private void FailConnect(Socket sock, string client)
        {
            // NOTE, MUST CLOSE THE SOCKET
            sock.Close();
            Invoke((MethodInvoker)delegate
            {
                //lbDisconnect.Items.Add(client.ToString() + "[IP의 Client 연결 실패].");
                tb_connect.AppendText(client.ToString() + "[IP의 Client 연결 실패]." + Environment.NewLine);
            });
        }

        public void ClientIPStore()
        {
            clientIP.Add("192.168.0.8");
            clientIP.Add("192.168.0.240");
            clientIP.Add("192.168.0.249");

        }

        private void iomsg()
        {
            string[] revmsg=data.Split(':');
            if(revmsg[0]=="C1")
            {
                string path = "D:\\Class1";
                DirectoryInfo mkdir = new DirectoryInfo(path);
                if (!mkdir.Exists)      //폴더 없을시 생성
                {
                    mkdir.Create();
                }


                if (revmsg[1].Substring(0, 1) == "P")
                {
                    if(revmsg[2]=="1")
                    {
                        player_in(Convert.ToInt32(revmsg[1].Substring(1)));
                        player_state(Convert.ToInt32(revmsg[1].Substring(1)), Convert.ToInt32(revmsg[2]));
                    }
                    else
                    {
                        player_out(Convert.ToInt32(revmsg[1].Substring(1)));
                        player_state(Convert.ToInt32(revmsg[1].Substring(1)), Convert.ToInt32(revmsg[2]));
                    }
                }
                else if (revmsg[1] == "LED")
                {
                    if (revmsg[2] == "1")
                    {
                        led_state(1);
                    }
                    else
                    {
                        led_state(0);
                    }
                }
                else if (revmsg[1] == "CAM")
                {
                    if (revmsg[2] == "1")
                    {
                        camera_state(1);
                    }
                    else
                    {
                        camera_state(0);
                    }
                }
                else if (revmsg[1] == "state")
                {
                    data = "LED:" + led.ToString() + "CAM:" + camera.ToString();
                }
          
            }


        }
        

        private void bt_time_up_Click(object sender, EventArgs e)
        {
            min += 10;
            if (min == 60)
            {
                min = 0;
                hour++;
                if (hour == 24)
                {
                    hour = 8;
                    day++;
                    tb_data.Text = DateTime.Now.AddDays(day).ToString("yyyy-MM-dd");
                }
            }

            time = (hour * 60) + min;


            tb_time.Text = hour.ToString() + ":" + min.ToString();
        }

        private void bt_time_down_Click(object sender, EventArgs e)
        {
            if (hour == 8 && min == 0)
            {
                hour = 23;
                min = 50;
                day--;
                tb_data.Text = DateTime.Now.AddDays(day).ToString("yyyy-MM-dd");
            }
            else
            {
                if (min == 0)
                {
                    hour--;
                    min = 50;
                }
                else
                {
                    min -= 10;
                }
            }

            time = (hour * 60) + min;
            tb_time.Text = hour.ToString() + ":" + min.ToString();
        }

        private void iniInitialize()
        {
            camera_state(0);
            led_state(0);
            player_state(1, 0);
            player_state(2, 0);
            player_state(3, 0);
            player_state(4, 0);
            player_data_load(1);
            player_data_load(2);
            player_data_load(3);
            player_data_load(4);
            player_txt();
            tb_time.Text = hour.ToString() + ":" + min.ToString();
            tb_data.Text = DateTime.Now.ToString("yyyy-MM-dd");
        }

        private void led_state(int state)
        {
            switch (state)
            {
                case 0: 
                    {
                        la_LED.Text = "LED : OFF";
                        bt_LED_off.Enabled = false;
                        bt_LED_on.Enabled = true;
                        led = 0;
                    }                   
                    break;

                case 1:
                    {
                        la_LED.Text = "LED : ON";
                        bt_LED_on.Enabled = false;
                        bt_LED_off.Enabled = true;
                        led = 1;
                    }
                    break;
            }
                
        }

        private void camera_state(int state)
        {
            switch (state)
            {
                case 0:
                    {
                        la_CAMERA.Text = "CAMERA : OFF";
                        bt_CAMERA_off.Enabled = false;
                        bt_CAMERA_on.Enabled = true;
                        camera = 0;
                    }
                    break;

                case 1:
                    {
                        la_CAMERA.Text = "CAMERA : ON";
                        bt_CAMERA_on.Enabled = false;
                        bt_CAMERA_off.Enabled = true;
                        camera = 1;
                    }
                    break;
            }

        }


        private void bt_LED_on_Click(object sender, EventArgs e)
        {
            led_state(1);
        }

        private void bt_LED_off_Click(object sender, EventArgs e)
        {
            led_state(0);
        }

        private void bt_CAMERA_on_Click(object sender, EventArgs e)
        {
            camera_state(1);
        }

       
        private void bt_CAMERA_off_Click(object sender, EventArgs e)
        {
            camera_state(0);
        }

        private void tb_msg_TextChanged(object sender, EventArgs e)
        {

        }

        private void state_msg()
        {           
            msg_data = data.Split(':');
            for (int i = 1; i < 5; i++)       //player 1~4 입출입 변동 체크
            {
                if (Convert.ToInt32(msg_data[i]) != player[i])
                {
                    if (player[i] == 0)
                    {
                        player_state(i, 1);
                        player_in(i);
                    }
                }

                if (Convert.ToInt32(msg_data[5]) != led)
                {
                    if (led == 0)
                    {
                        led_state(1);
                    }
                    else
                    {
                        led_state(0);
                    }
                }
                if (Convert.ToInt32(msg_data[6]) != camera)
                {
                    if (camera == 0)
                    {
                        camera_state(1);
                    }
                    else
                    {
                        camera_state(0);
                    }
                }
            }

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void player_state(int who, int state)
        {
            switch (who)
            {
                case 1:
                    {
                        if (state == 0)
                        {
                            la_player1.Text = "player1 : out";

                            player[1] = 0;
                        }
                        else
                        {
                            la_player1.Text = "player1 : in";
                            player[1] = 1;

                        }
                    }
                    break;

                case 2:
                    {
                        if (state == 0)
                        {
                            la_player2.Text = "player2 : out";
                            player[2] = 0;
                        }
                        else
                        {
                            la_player2.Text = "player2 : in";
                            player[2] = 1;

                        }
                    }
                    break;

                case 3:
                    {
                        if (state == 0)
                        {
                            la_player3.Text = "player3 : out";
                            player[3] = 0;
                        }
                        else
                        {
                            la_player3.Text = "player3 : in";
                            player[3] = 1;

                        }
                    }
                    break;

                case 4:
                    {
                        if (state == 0)
                        {
                            la_player4.Text = "player4 : out";
                            player[4] = 0;
                        }
                        else
                        {
                            la_player4.Text = "player4 : in";
                            player[4] = 1;

                        }
                    }
                    break;
            }

        }

        private void player_data_load(int player)
        {
           string path = "D:\\Class1\\player_attend";

            DirectoryInfo mkdir = new DirectoryInfo(path);
            if (!mkdir.Exists)      //폴더 없을시 생성
            {
                mkdir.Create();
            }

            path += "\\player"+player.ToString()+".txt";
            if (!File.Exists(path))
            {
                using (File.Create(path)) ;
                StreamWriter writer;
                writer = File.AppendText(path);
                writer.WriteLine(DateTime.Now.ToString("P"+player.ToString()+"_0_0_0_0"));      //텍스트파일없을시 
                writer.Close();
            }
            StreamReader Log_Data = new StreamReader(path);
            string line;
            while ((line = Log_Data.ReadLine()) != null)
            {



                string[] P_data = line.Split('_');

                for (int i = 1; i < 5; i++)
                {
                    player_data[player,i] = Convert.ToInt32(P_data[i]);
                
                }

                player_txt();
            }
            Log_Data.Close();

        }

        private void player_in(int player)
        {
            string path = "D:\\Class1\\player_log";
            DirectoryInfo mkdir = new DirectoryInfo(path);
            if (!mkdir.Exists)      //폴더 없을시 생성
            {
                mkdir.Create();
            }

            path += "\\player"+player.ToString()+".txt";
            if (!File.Exists(path))
            {
                using (File.Create(path)) ;
            }
            if (hour <= 9)
            {
                //8시에 입실체크.
                if (hour == 8)
                {
                    StreamReader PRead = new StreamReader(path);

                    //한줄씩 txt파일을 읽는 코드.
                    while ((line = PRead.ReadLine()) != null)
                    {
                        string[] User_Data = line.Split('.');
                        Log_Num = Convert.ToInt32(User_Data[0]);
                    }

                    PRead.Close();
                    StreamWriter PInOut = new StreamWriter(path);
                    PInOut = File.AppendText(path);
                    PInOut.WriteLine(Log_Num + 1.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour.ToString() + "-" + min.ToString() + " " +
                                    "정상 입실");
                    PInOut.WriteLine((Log_Num + 2).ToString() + "." + "$");
                    PInOut.Close();


                }
                else
                {
                    //9시 20분까지 입실 체크.
                    if (min <= 20)
                    {
                        StreamReader PRead = new StreamReader(path);



                        //한줄씩 txt파일을 읽는 코드.
                        while ((line = PRead.ReadLine()) != null)
                        {
                            string[] User_Data = line.Split('.');
                            Log_Num = Convert.ToInt32(User_Data[0]);
                        }

                        PRead.Close();
                        StreamWriter PInOut = new StreamWriter(path);
                        PInOut = File.AppendText(path);
                        PInOut.WriteLine(Log_Num + 1.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour.ToString() + "-" + min.ToString() + " " +
                                        "정상 입실");
                        PInOut.WriteLine((Log_Num + 2).ToString() + "." + "$");
                        PInOut.Close();


                    }
                    //9시 20분 이후에 출석 체크를 했을시
                    else
                    {
                        Minute_Compare = min - 20;
                        StreamReader PRead = new StreamReader(path);
                        while ((line = PRead.ReadLine()) != null)
                        {
                            string[] User_Data = line.Split('.');
                            Log_Num = Convert.ToInt32(User_Data[0]);
                        }
                        PRead.Close();
                        StreamWriter PInOut = new StreamWriter(path);
                        PInOut = File.AppendText(path);
                        PInOut.WriteLine(Log_Num + 1.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" +
                                        hour.ToString() + "-" + min.ToString() + " " + Minute_Compare.ToString() + "분 지각");

                        PInOut.WriteLine((Log_Num + 1).ToString() + "." + "$");
                        PInOut.Close();
                        player_late[player] = true;


                    }
                }
            }
            //입실 체크 시간 10시 이후
            else
            {
                // 13시전에 입실 체크
                if (hour <= 12)
                {
                    Hour_Compare = (hour * 60 + min) - 560;
                    Minute_Compare = Hour_Compare % 60;
                    Hour_Compare = Hour_Compare / 60;
                    StreamReader PRead = new StreamReader(path);
                    while ((line = PRead.ReadLine()) != null)
                    {
                        string[] User_Data = line.Split('.');
                        Log_Num = Convert.ToInt32(User_Data[0]);
                    }
                    PRead.Close();
                    StreamWriter PInOut = new StreamWriter(path);
                    PInOut = File.AppendText(path);
                    PInOut.WriteLine(Log_Num + 1.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour.ToString() +
                                        "-" + min.ToString() + " " + Hour_Compare.ToString() + "시간 " + Minute_Compare.ToString() + "분 지각");

                    PInOut.WriteLine((Log_Num + 2).ToString() + "." + "$");
                    PInOut.Close();

                    player_late[player] = true;

                }
                //그 이후의 시간, 결석처리.
                else
                {
                    StreamReader PRead = new StreamReader(path);
                    while ((line = PRead.ReadLine()) != null)
                    {
                        string[] User_Data = line.Split('.');
                        Log_Num = Convert.ToInt32(User_Data[0]);
                    }
                    PRead.Close();
                    StreamWriter PInOut = new StreamWriter(path);
                    PInOut = File.AppendText(path);
                    PInOut.WriteLine(Log_Num + 1.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" +
                                        hour.ToString() + "-" + min.ToString() + " " + "결석 처리");
                    PInOut.WriteLine((Log_Num + 2).ToString() + "." + "$");
                    PInOut.Close();
                    player_absent[player] = true;
                }

            }
            tb_msg.AppendText("player" + player.ToString()+" " + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd")+" " + hour.ToString() + ":" + min.ToString() + " 입실\r\n");
        }

        private void player_out(int player)
        {
            string path = "D:\\Class1\\player_log";

            path += "\\player"+player.ToString()+".txt";

            if (player_absent[player])
            {
                StreamReader PRead = new StreamReader(path);
                while ((line = PRead.ReadLine()) != null)
                {
                    string[] User_Data = line.Split('.');
                    //퇴실관련된 줄인지 확인 하기위하여 입실할때 미리 한줄 더 생성함.
                    if (User_Data[1] == "$")
                    {
                        Log_Num = Convert.ToInt32(User_Data[0]);

                    }
                }
                PRead.Close();
                text = File.ReadAllText(path);
                text = text.Replace(Log_Num.ToString() + ".$", Log_Num.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour +
                "-" + min + " 결석 처리");
                File.WriteAllText(path, text);


                player_data[player,4]++;
                player_absent[player] = false;
                player_txt();
            }

            else
            {
                //13시40분전에 퇴실을 찍었을시.
                if (time < 820)
                {
                    StreamReader P1Read = new StreamReader(path);
                    while ((line = P1Read.ReadLine()) != null)
                    {
                        string[] User_Data = line.Split('.');
                        if (User_Data[1] == "$")
                        {
                            Log_Num = Convert.ToInt32(User_Data[0]);

                        }
                    }
                    P1Read.Close();
                    text = File.ReadAllText(path);
                    text = text.Replace(Log_Num.ToString() + ".$", Log_Num.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour +
                    "-" + min + " " + "결석 처리");
                    File.WriteAllText(path, text);

                    player_data[player,4]++;
                    player_absent[player] = false;
                    player_txt();

                }
                //13시40분 이후, 16시 40분전에 퇴실을 찍었을시.
                if (time >= 820 && time < 1000)
                {
                    if (player_late[player])
                    {
                        StreamReader P1Read = new StreamReader(path);
                        while ((line = P1Read.ReadLine()) != null)
                        {
                            string[] User_Data = line.Split('.');
                            if (User_Data[1] == "$")
                            {
                                Log_Num = Convert.ToInt32(User_Data[0]);

                            }
                        }
                        P1Read.Close();
                        text = File.ReadAllText(path);
                        text = text.Replace(Log_Num.ToString() + ".$", Log_Num.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour +
                        "-" + min + " " + "결석 처리");
                        File.WriteAllText(path, text);

                        player_data[player,4]++;
                        player_late[player] = false;
                        player_txt();

                    }
                    //이미 지각한 상황이 아닐시에.
                    else
                    {
                        StreamReader P1Read = new StreamReader(path);
                        while ((line = P1Read.ReadLine()) != null)
                        {
                            string[] User_Data = line.Split('.');
                            if (User_Data[1] == "$")
                            {
                                Log_Num = Convert.ToInt32(User_Data[0]);

                            }
                        }
                        P1Read.Close();
                        text = File.ReadAllText(path);
                        text = text.Replace(Log_Num.ToString() + ".$", Log_Num.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour +
                        "-" + min + " " + "조퇴 처리");
                        File.WriteAllText(path, text);

                        player_data[player,3]++;
                        player_txt();

                    }
                }



                //16:40분 이후 퇴실.
                if (time >= 1000)
                {
                    if (player_late[player])
                    {
                        StreamReader P1Read = new StreamReader(path);
                        while ((line = P1Read.ReadLine()) != null)
                        {
                            string[] User_Data = line.Split('.');
                            if (User_Data[1] == "$")
                            {
                                Log_Num = Convert.ToInt32(User_Data[0]);

                            }
                        }
                        P1Read.Close();
                        text = File.ReadAllText(path);
                        text = text.Replace(Log_Num.ToString() + ".$", Log_Num.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour +
                        "-" + min + " " + "지각 처리");
                        File.WriteAllText(path, text);

                        player_data[player,2]++;
                        player_late[player] = false;
                        player_txt();
                    }
                    else
                    {


                        StreamReader P1Read = new StreamReader(path);
                        while ((line = P1Read.ReadLine()) != null)
                        {
                            string[] User_Data = line.Split('.');
                            if (User_Data[1] == "$")
                            {
                                Log_Num = Convert.ToInt32(User_Data[0]);

                            }
                        }
                        P1Read.Close();
                        text = File.ReadAllText(path);
                        text = text.Replace(Log_Num.ToString() + ".$", Log_Num.ToString() + "." + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + "-" + hour +
                        "-" + min + " " + "정상 퇴실");
                        File.WriteAllText(path, text);

                        player_data[player,1]++;
                        player_txt();
                    }
                }
            }
            tb_msg.AppendText("player" + player.ToString() + " " + DateTime.Now.AddDays(day).ToString("yyyy-MM-dd") + " " + hour.ToString() + ":" + min.ToString() + " 퇴실\r\n");
        }
        

        private void player_txt()
        {
            tb_player1.Text = player_data[1, 1].ToString() + "." + player_data[1, 2].ToString() + "." + player_data[1, 3].ToString() + "." + player_data[1, 4].ToString();
            tb_player2.Text = player_data[2, 1].ToString() + "." + player_data[2, 2].ToString() + "." + player_data[2, 3].ToString() + "." + player_data[2, 4].ToString();
            tb_player3.Text = player_data[3, 1].ToString() + "." + player_data[3, 2].ToString() + "." + player_data[3, 3].ToString() + "." + player_data[3, 4].ToString();
            tb_player4.Text = player_data[4, 1].ToString() + "." + player_data[4, 2].ToString() + "." + player_data[4, 3].ToString() + "." + player_data[4, 4].ToString();
        }

        private void save_data()
        {
            StreamWriter writer;
            writer = File.CreateText("D:\\Class1\\player_attend\\player1.txt");       
            writer.WriteLine("P_"+player_data[1,1].ToString()+"_"+ player_data[1, 2].ToString()+"_" + player_data[1, 3].ToString()+"_" + player_data[1, 4].ToString());
            writer.Close();

            writer = File.CreateText("D:\\Class1\\player_attend\\player2.txt");
            writer.WriteLine("P_" + player_data[2, 1].ToString() + "_" + player_data[2, 2].ToString() + "_" + player_data[2, 3].ToString() + "_" + player_data[2, 4].ToString());
            writer.Close();

            writer = File.CreateText("D:\\Class1\\player_attend\\player3.txt");
            writer.WriteLine("P_" + player_data[3, 1].ToString() + "_" + player_data[3, 2].ToString() + "_" + player_data[3, 3].ToString() + "_" + player_data[3, 4].ToString());
            writer.Close();

            writer = File.CreateText("D:\\Class1\\player_attend\\player4.txt");
            writer.WriteLine("P_" + player_data[4, 1].ToString() + "_" + player_data[4, 2].ToString() + "_" + player_data[4, 3].ToString() + "_" + player_data[4, 4].ToString());
            writer.Close();



        }

    }
}
