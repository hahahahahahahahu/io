﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace io
{
    public partial class Form2 : Form
    {
        public int attend = 0, late = 0, leave = 0,absence=0;
        public Form2()
        {
            InitializeComponent();
        }

        private void bt_close_Click(object sender, EventArgs e)
        {
            Application.OpenForms["Form2"].Hide();
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void tb_player1_attend_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}
